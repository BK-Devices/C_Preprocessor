#include"myHeader.h"

char *replace_macro(char *data)
{
	int j=0,l1=0,l2=0;
	char *str=NULL, *ptr=NULL;
	char m_name[30],m_exp[50];
	
	data=realloc(data,strlen(data)+(strlen(data)/2));
	str=data;

	while(str=strstr(str,"#define "))
	{
		ptr=str;
		str+=8;
		while(*str==' ') str++;

		for(j=0;*str!=' ';j++,str++)
		{
			m_name[j]=*str;
		}
		m_name[j]='\0';

		while(*str==' ') str++;
		
		for(j=0;*str!='\n' && *str!=' ';str++,j++)
		{
			m_exp[j]=*str;
		}
		m_exp[j]='\0';
		
		memmove(ptr,str,strlen(str)+1);

		l1=strlen(m_name);
		l2=strlen(m_exp);

		ptr = data;

		while(ptr=strstr(ptr,m_name))
		{
			memmove(ptr+l2,ptr+l1,strlen(ptr+l1)+1);
			strncpy(ptr,m_exp,l2);
			ptr+=l1;
		}
	}
	
	data=realloc(data,strlen(data)+1);

	return data;
}
