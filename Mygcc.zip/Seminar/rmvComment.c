#include"myHeader.h"

void remove_comments(char *data)
{
	char *str=NULL,*endcmt=NULL;
	int i=0;

	str=data;
	while(str=strstr(str,"//"))
	{
		i=0;
		while(str[i]!='\n') i++;

		memmove(str,str+i,strlen(str+i)+1);
	}

	str=data;
	while(str=strstr(str,"/*"))
	{
		if(endcmt=strstr(str+2,"*/"))
		{
			memmove(str,endcmt+2,strlen(endcmt+2)+1);
		}
		else
		{
			printf("Error: unterminated '/*' comment \n");
        	exit(0);
		}
	}
}
