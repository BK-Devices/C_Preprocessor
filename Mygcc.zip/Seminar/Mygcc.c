#include"myHeader.h"

int chkFileTyp(char *filenm)
{
	int len=strlen(filenm)-2;

	if(!strcmp(filenm+len,".c"))
		return 1;
	
    return 0;
}


char *read_from_file(char *filenm)
{
	char *str=NULL;
	unsigned int size=0;
	FILE *fp=fopen(filenm,"r");

	if(fp==NULL)
	{
		printf("Error: %s: no such file or directory\n",filenm);
		exit(0);
	}
	else
	{
		fseek(fp,0,2);
		size=ftell(fp);
		rewind(fp);

		str=calloc(size+1,1);      

		fread(str,size,1,fp);
		str[size]='\0';

		fclose(fp);

		return str;
	}
}


int main(int argc,char *argv[])
{
	char *data=NULL;

	if(argc!=2)
	{
		printf("Error: exe filename.c\n");
		return 0;
	}
	
	if(chkFileTyp(argv[1])==0)
	{
		printf("Error: invalid file format\n");
		return 0;
	}
	
	data=read_from_file(argv[1]);

	remove_comments(data);
	
	data=replace_macro(data);

	include_header(data,argv[1]);
	
	return 0;
}
