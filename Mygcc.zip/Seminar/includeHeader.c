#include"myHeader.h"


#ifdef _WIN32
    char PATH[60] = "C:\\MinGW\\include\\";
    int len=17;
#elif __linux__
    char PATH[60] = "/usr/include/";
    int len=13;
#endif


int checkSpaces(char *start, char *end)
{
    while(start<end)
    {
        if(*start!=' ') return 0;
        start++;
    }
    return 1;
}


void include_header(char *data, char *filenm)
{
    char *start=data, *end=NULL;
    char *str=NULL, *copy=NULL;
    int i=0;

    filenm[strlen(filenm)-1]='i';
	FILE *fp=fopen(filenm,"w");

    while(end=strchr(start, '\n'))
    {
        *end='\0';
        if(str=strstr(start, "#include"))
        {
            if(checkSpaces(start, str)==1)
            {
                str+=8;
                i=len;
                while(*str==' ') str++; // Skiping Spaces
                
                if(*str=='<')
                {
                    str++;
                    while(*str!='>')
                    {
                        if(*str=='\0')
                        {
                            printf("Error: missing terminating char '>'\n");
                            exit(0);
                        }
                        PATH[i++]=*str++;
                    }
                    PATH[i]='\0';
                    copy=read_from_file(PATH);
                }
                else if(*str=='"')
                {
                    str++;
                    while(*str!='"')
                    {
                        if(*str=='\0')
                        {
                            printf("Error: missing terminating char '\"'\n");
                            exit(0);
                        }
                        PATH[i++]=*str++;
                    }
                    PATH[i]='\0';
                    copy=read_from_file(PATH+len);
                }
                else
                {
                    printf("Error: expected \"FILENAME\" or <FILENAME>\n");
			        exit(0);
                }
    
                remove_comments(copy);		
                fputs(copy,fp);
                free(copy);
                
                memmove(start,end+1,strlen(end+1)+1);
            }
            else
            {
                *end='\n';
                start=end+1;
            }
        }
        else
        {
            *end='\n';
            start=end+1;
        }
    }

    fputs(data,fp);
	free(data);	
	fclose(fp);
}








/*
#include"myHeader.h"

#define MAX 60

// Finding System 
#ifdef _WIN32
    char PATH[MAX] = "C:\\MinGW\\include\\";
    int len=17;
#elif __APPLE__
    char PATH[MAX] = " ";
    int len=0;
#elif __linux__
    char PATH[MAX] = "/usr/include/";
    int len=13;
#endif


void include_header(char *data,char *filenm)
{
    char *str=data,*copy=NULL,*ptr=NULL;
	int i=0;

	filenm[strlen(filenm)-1]='i';
	FILE *fp=fopen(filenm,"w");
	
	while(str=strstr(str,"#include"))
	{
		ptr=str;
		str+=8;

		while(*str==' ') str++;

        i=len;
		if(*str=='<')
		{
			str++;
			while(*str!='>')
			{
				if(*str=='\n')
				{
					printf("Error: missing terminating char '>'\n");
					exit(0);
				}
				PATH[i++]=*str++;
			}
			copy=read_from_file(PATH);
		}
		else if(*str=='"')
		{
			str++;
			while(*str!='"')
			{
				if(*str=='\n')
				{
					printf("Error: missing terminating char '\"'\n");
					exit(0);
				}
				PATH[i++]=*str++;
			}
			copy=read_from_file(PATH+len);
		}
		else
		{
			printf("Error: expected \"FILENAME\" or <FILENAME>\n");
			exit(0);
		}

		remove_comments(copy);
		
		fputs(copy,fp);
		free(copy);
		
		memmove(ptr,str+1,strlen(str+1)+1);
	}

	fputs(data,fp);
	free(data);	
	fclose(fp);
}
*/
