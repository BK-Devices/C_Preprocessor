#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int chkFileTyp(char *filenm);
char *read_from_file(char *filenm);
void remove_comments(char *data);
char *replace_macro(char *data);
int checkSpaces(char *start, char *end);
void include_header(char *data,char *filenm);
