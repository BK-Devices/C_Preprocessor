#include"header.h"

char *readLine(FILE *file){
    char *line=NULL, ch;
    int i=0;
    
    while((ch = fgetc(file))!=EOF){
        line = realloc(line, i+1);
        line[i++]=ch;
        if(ch=='\n') break;
    }
    line = realloc(line, i+1);
    line[i]='\0';

    return line;
}

int chkFileTyp(char *filenm){
    if(filenm = strrchr(filenm,'.')){
        if(!strcmp(filenm,".c")) return 1;
        else if(!strcmp(filenm,".i")) return 2;
        else return -1;
    }
    return 0;
}

int chkFile(char *filenm){
    if(access(filenm, F_OK) == -1) return 0;
    return 1;
}

void copyFile(FILE *dest, FILE *src){
    char ch;
    rewind(src);
    while((ch=fgetc(src)) != EOF){
        fputc(ch, dest);
    }
    return;
}

int chkSpaces(char *src, char *dest){
    while(src < dest){
        if(*src != ' ') return 0;
        src++;
    }
    return 1;
}

int chkOpenStr(char *src, char *dest){
    int cnt=0;
    while(src<dest){
        if(*src=='"') cnt++;
        src++;
    }
    return cnt%2;
}
