#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>

// Comment.c
void rmvComment(char *filenm);

// File.c
char *readLine(FILE *file);
int chkFileTyp(char *filenm);
int chkFile(char *filenm);
void copyFile(FILE *dest, FILE *src);
int chkSpaces(char *src, char *dest);
int chkOpenStr(char *src, char *dest);

// Include.c
void include(char *filenm, FILE *dest);
void headerInclude(char *filenm, char typ);

// Macros.c
void findMacro(char *filenm);
void replaceMacros(char *filenm);

