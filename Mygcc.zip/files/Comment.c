#include"header.h"

void rmvComment(char *filenm){
    FILE *fp, *tmp;
    char ch;
    int str=0, sLine=0, mLine=0;

    fp = fopen(filenm, "r");
    tmp = tmpfile();

    while((ch=fgetc(fp)) != EOF){
        if(str){
            if(ch=='"') str=0;
            fputc(ch, tmp);
        }
        else if(sLine){
            if(ch=='\n'){
                sLine=0;
                fputc(ch, tmp);
            }
        }
        else if(mLine){
            if(ch=='*'){
                if((ch = fgetc(fp)) == '/') mLine=0;
                else fseek(fp, -1, 1);
            }
        }
        else if(ch=='/'){
            ch = fgetc(fp);
            if(ch=='/') sLine=1;
            else if(ch=='*') mLine=1;
            else{
                fputc('/', tmp);
                fputc(ch, tmp);
            }
        }
        else if(ch == '"'){
            str=1;
            fputc(ch, tmp);
        }
        else fputc(ch, tmp);
    }

    fclose(fp);

    // if unterminated multiline comment
    if(mLine || str){
        fclose(tmp);
        remove(filenm);
        printf("Error: unterminated '/*' comment or \" char\n");
        exit(0);
    }
    
    // copying to same file
    fp = fopen(filenm, "w");
    copyFile(fp, tmp);
    fclose(fp);
    fclose(tmp);

    return;
}
