#include"header.h"

struct macro{
    char *nm;
    char *val;
} *mac;
int macCnt=0;

void findMacro(char *filenm){
    FILE *fp, *tmp;
    char *line, *str;
    char *key=NULL, *val=NULL;
    int i=0;

    fp = fopen(filenm, "r");
    tmp = tmpfile();

    while(!feof(fp)){
        line = readLine(fp);
        if((str = strstr(line, "#define")) && chkSpaces(line, str)){
            str+=7;
            if(*str!=' '){
                printf("Error: invalid preprocessing directive\n");
                fclose(fp);
                remove(filenm);
                exit(0);
            }
            while(*str==' ') str++;
            if(*str=='\0' || *str=='\n'){
                printf("Error: no macro name given in #define directive\n");
                fclose(fp);
                remove(filenm);
                exit(0);
            }

            key=NULL; val=NULL;
            mac = realloc(mac, (macCnt+1)*sizeof(*mac));

            i=0;
            key = realloc(key, i+1);
            while(*str!=' ' && *str!='\0' && *str!='\n'){
                key[i++]=*str;
                str++;
                key = realloc(key, i+1);
            }
            key[i]='\0';

            while(*str==' ') str++;            

            i=0;
            val = realloc(val, i+1);
            while(*str!=' ' && *str!='\0' && *str!='\n'){
                val[i++]=*str;
                str++;
                val = realloc(val, i+1);
            }
            val[i]='\0';

            mac[macCnt].nm = key;
            mac[macCnt++].val = val;

        }
        else fputs(line, tmp);
        free(line);
    }
    fclose(fp);

    fp = fopen(filenm, "w");
    copyFile(fp, tmp);
    fclose(fp);
    fclose(tmp);
}

void replaceMacros(char *filenm){
    FILE *fp, *tmp;
    char *line, *str1, *str2;
    int i=0;

    findMacro(filenm);

    for(i; i<macCnt; i++){
        fp = fopen(filenm, "r");
        tmp = tmpfile();

        while(!feof(fp)){
            line = readLine(fp);
            str1 = line;
            
            REPEAT:
            if((str2 = strstr(str1, mac[i].nm))){
                *str2 = '\0';
                fputs(str1, tmp);
                
                if(chkOpenStr(line, str2) == 0){
                    fputs(mac[i].val, tmp);
                }
                else{
                    fputs(mac[i].nm, tmp);
                }

                str1 = str2+strlen(mac[i].nm);
                goto REPEAT;
            }
            else{
                fputs(str1, tmp);
            }
            free(line);
        }

        fclose(fp);

        fp = fopen(filenm, "w");
        copyFile(fp, tmp);
        fclose(fp);
        fclose(tmp);
    }
}