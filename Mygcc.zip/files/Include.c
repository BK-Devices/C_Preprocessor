#include"header.h"

// Finding System 
#ifdef _WIN32
    const char PATH[] = "C:\\MinGW\\include\\";
#elif __APPLE__
    const char PATH[] = " ";
#elif __linux__
    const char PATH[] = "/usr/include/";
#endif


void include(char *filenm, FILE *dest){
    if(!chkFile(filenm)){
        printf("Error: %s: no such file or directory", filenm);
        remove(filenm);
        exit(0);
    }
    FILE *src = fopen(filenm, "r");
    copyFile(dest, src);
    fclose(src);

    return;
}

void headerInclude(char *filenm, char typ){
    FILE *fp, *tmp;
    int incCnt=0;
    char *line, header[50];
    char *str1, *str2;

    do{
        incCnt=0;
        fp = fopen(filenm, "r");
        tmp = tmpfile();

        while(!feof(fp)){
            line = readLine(fp);

            if((str1 = strstr(line, "#include")) && chkSpaces(line, str1)){
                str1+=8;
                if(typ=='U'){
                    if((str2 = strchr(str1, '"')) && chkSpaces(str1, str2)){
                        if(str1 = strchr(str2+1, '"')){
                            *str1 = '\0';
                            include(str2+1, tmp);
                            incCnt++;
                        }
                        else{
                            printf("Error: missing \" char\n");
                            fclose(fp);
                            remove(filenm);
                            exit(0);
                        }
                    }
                    else{
                        fputs(line, tmp);
                    }
                }
                else if(typ=='P'){
                    if((str2 = strchr(str1, '<')) && chkSpaces(str1, str2)){
                        if(str1 = strchr(str2+1, '>')){
                            *str1 = '\0';
                            strcpy(header, PATH);
                            strcat(header, str2+1);
                            include(header, tmp);
                        }
                        else{
                            printf("Error: missing > char\n");
                            fclose(fp);
                            remove(filenm);
                            exit(0);
                        }
                    }
                    else{
                        printf("Error: expects \"FILENAME\" or <FILENAME>\n");
                        fclose(fp);
                        remove(filenm);
                        exit(0);
                    }
                }
            }
            else{
                fputs(line, tmp);
            }
            free(line);
        }

        fclose(fp);
        fp = fopen(filenm, "w");
        copyFile(fp, tmp);
        fclose(fp);
        fclose(tmp);

        rmvComment(filenm);
    } while(incCnt);
}

