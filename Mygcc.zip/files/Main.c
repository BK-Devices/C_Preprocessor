#include"header.h"

int main(int argc, char *argv[]){
    int res;
    FILE *fp, *tmp;

    if(argc!=5){
        ERROR:
        printf("Error: exe -E filename.c -o filename.i\n"); 
        exit(0);
    }
    
    if(strcmp(argv[1], "-E") || strcmp(argv[3], "-o")) goto ERROR;
    if(chkFileTyp(argv[2]) != 1 || chkFileTyp(argv[4]) != 2){
        printf("Error: invalid file format\n");
        goto ERROR;
    }

    if(!chkFile(argv[2])) {
        printf("Error: %s: no such file or directory\n", argv[2]);
        exit(0);
    }

    // copying to same file
    tmp = fopen(argv[2], "r");
    fp = fopen(argv[4], "w");
    copyFile(fp, tmp);
    fclose(fp);
    fclose(tmp);

    rmvComment(argv[4]);
    headerInclude(argv[4], 'U');
    replaceMacros(argv[4]);
    headerInclude(argv[4], 'P');
}